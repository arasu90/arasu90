# shell script will execute it create automatically to you application using start.sh
    # execute in Terminal
    
    cd project_folder
    ./start.sh
    or 
    /bin/bash start.sh

# after the script we have to give composer name, container name, access web port number and db port number

# start.sh file will create default odoo config file and update the file has default setting

# go to docker desktop then cross verify the docker container