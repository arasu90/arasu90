#!/bin/bash
set -e

echo "Starting entrypoint script..."

# Install python3-tk if missing
if ! dpkg -s python3-tk > /dev/null 2>&1; then
    echo "python3-tk not found, installing..."
    apt-get update
    apt-get install -y python3-tk
fi

# Install python packages if missing
required_packages=("pyjwt" "python-barcode" "pycryptodome")

for pkg in "${required_packages[@]}"; do
    if ! pip show "$pkg" > /dev/null 2>&1; then
        echo "Installing python package: $pkg"
        pip install "$pkg"
    fi
done

echo "Starting Odoo server..."

# Execute the CMD from Dockerfile (odoo server)
exec "$@"
