#!/bin/bash

# Create folders if they don't exist
mkdir -p addons config log

CONFIG_FILE="config/odoo.conf"

# Check if the file exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Creating $CONFIG_FILE..."
    cat <<EOF > "$CONFIG_FILE"
[options]
admin_passwd = Adm!n
db_port = 5432
db_user = odoo
db_password = odoo
addons_path = /mnt/extra-addons
logfile = /var/log/odoo/odoo.log
EOF
else
    echo "$CONFIG_FILE already exists. Skipping creation."
fi

echo "Config file created at config/odoo.conf"

# Ask user for container names and ports (with defaults)

# Read inputs or set defaults
read -p "Enter Docker Compose project name [odooproject]: " COMPOSE_PROJECT_NAME
COMPOSE_PROJECT_NAME=${COMPOSE_PROJECT_NAME:-odooproject}

read -p "Enter Odoo port on host [8069]: " ODOO_PORT
ODOO_PORT=${ODOO_PORT:-8069}

read -p "Enter Postgres port on host [54320]: " PG_PORT
PG_PORT=${PG_PORT:-54320}

read -p "Enter Odoo container name [odoo16-app]: " ODOO_CONTAINER_NAME
ODOO_CONTAINER_NAME=${ODOO_CONTAINER_NAME:-odoo16-app}

read -p "Enter Postgres container name [odoo16-db]: " DB_CONTAINER_NAME
DB_CONTAINER_NAME=${DB_CONTAINER_NAME:-odoo16-db}

# Export as environment variables for docker-compose to pick up
export COMPOSE_PROJECT_NAME
export ODOO_CONTAINER_NAME
export DB_CONTAINER_NAME
export ODOO_PORT
export PG_PORT

# Run docker-compose with build and detached mode
docker-compose up -d --build


